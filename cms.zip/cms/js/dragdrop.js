// ================================
// Drag & Drop for Arrays
// ================================

function makeDraggable(containerSelector) {
  const containers = document.querySelectorAll(containerSelector);

  containers.forEach(container => {
    let dragItem = null;

    container.addEventListener("dragstart", e => {
      dragItem = e.target;
      e.dataTransfer.effectAllowed = "move";
    });

    container.addEventListener("dragover", e => {
      e.preventDefault();
      e.dataTransfer.dropEffect = "move";
      const target = e.target.closest(".draggable-item");
      if (!target || target === dragItem) return;
      const rect = target.getBoundingClientRect();
      const next = (e.clientY - rect.top) / (rect.bottom - rect.top) > 0.5;
      container.insertBefore(dragItem, next ? target.nextSibling : target);
    });

    container.addEventListener("drop", e => {
      e.preventDefault();
      dragItem = null;
    });
  });
}

// Usage: call makeDraggable(".array-container") after DOM loaded
