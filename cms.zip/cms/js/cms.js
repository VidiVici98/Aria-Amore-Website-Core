// ================================
// CMS JS — Polished Version
// ================================
document.addEventListener("DOMContentLoaded", () => {
  const tabs = document.querySelectorAll(".tab-btn");
  const tabContents = document.querySelectorAll(".cms-tab-content");
  const saveAllBtn = document.getElementById("save-all-btn");
  const toast = document.getElementById("toast");
  let activeTab = null;

  // -----------------------
  // Tab switching
  // -----------------------
  function switchTab(tabKey) {
    tabs.forEach(t => t.classList.remove("active"));
    tabContents.forEach(c => c.classList.remove("active"));
    const btn = document.querySelector(`.tab-btn[data-tab="${tabKey}"]`);
    const content = document.getElementById(`tab-${tabKey}`);
    if (btn && content) {
      btn.classList.add("active");
      content.classList.add("active");
      activeTab = tabKey;
    }
  }
  tabs.forEach(tab => tab.addEventListener("click", () => switchTab(tab.dataset.tab)));
  if (tabs.length > 0) switchTab(tabs[0].dataset.tab);

  // -----------------------
  // Toast Notifications
  // -----------------------
  function showToast(msg, duration = 3000) {
    toast.textContent = msg;
    toast.classList.add("show");
    setTimeout(() => toast.classList.remove("show"), duration);
  }

  // -----------------------
  // Drag & Drop
  // -----------------------
  function makeDraggable(containerSelector) {
    const containers = document.querySelectorAll(containerSelector);
    containers.forEach(container => {
      let dragItem = null;
      container.addEventListener("dragstart", e => {
        dragItem = e.target;
        e.target.classList.add("dragging");
      });
      container.addEventListener("dragend", e => {
        dragItem.classList.remove("dragging");
        dragItem = null;
      });
      container.addEventListener("dragover", e => {
        e.preventDefault();
        const target = e.target.closest(".draggable-item");
        if (!target || target === dragItem) return;
        const rect = target.getBoundingClientRect();
        const next = (e.clientY - rect.top) / (rect.bottom - rect.top) > 0.5;
        container.insertBefore(dragItem, next ? target.nextSibling : target);
      });
    });
  }

  // -----------------------
  // JSON Structured Editor
  // -----------------------
  function createEditor(container, data, path = []) {
    container.innerHTML = "";

    function setDataAtPath(path, value) {
      let obj = data;
      for (let i = 0; i < path.length - 1; i++) obj = obj[path[i]];
      obj[path[path.length - 1]] = value;
    }

    function updateRawJSON() {
      const pre = container.querySelector(".json-raw");
      if (pre) pre.textContent = JSON.stringify(data, null, 2);
    }

    function buildNode(value, key, parentPath) {
      const node = document.createElement("div");
      node.classList.add("editor-node");

      if (typeof value === "object" && value !== null) {
        const isArray = Array.isArray(value);
        const header = document.createElement("div");
        header.classList.add("node-header");
        header.textContent = `${key} ${isArray ? "[Array]" : "{Object}"}`;
        header.title = "Click to collapse/expand";
        const content = document.createElement("div");
        content.classList.add("node-content");
        header.addEventListener("click", () => content.classList.toggle("collapsed"));

        if (isArray) {
          const arrayContainer = document.createElement("div");
          arrayContainer.classList.add("array-container");

          value.forEach((item, index) => {
            const itemNode = buildNode(item, index, parentPath.concat(index));
            itemNode.classList.add("draggable-item");
            arrayContainer.appendChild(itemNode);
          });

          const addBtn = document.createElement("button");
          addBtn.textContent = "+ Add Item";
          addBtn.classList.add("add-array-item");
          addBtn.title = "Add a new item with default fields";
          addBtn.addEventListener("click", () => {
            // Default object for new array item
            let defaultItem = {};
            const sampleItem = value[0];
            if (sampleItem && typeof sampleItem === "object") {
              for (const k in sampleItem) defaultItem[k] = typeof sampleItem[k] === "string" ? "" : {};
            }
            value.push(defaultItem);

            const itemNode = buildNode(defaultItem, value.length - 1, parentPath.concat(value.length - 1));
            itemNode.classList.add("draggable-item");
            arrayContainer.insertBefore(itemNode, addBtn);
            updateRawJSON();
            makeDraggable(".array-container");
          });

          arrayContainer.appendChild(addBtn);
          node.appendChild(header);
          node.appendChild(arrayContainer);
          makeDraggable(".array-container");
        } else {
          for (const k in value) {
            content.appendChild(buildNode(value[k], k, parentPath.concat(k)));
          }
          node.appendChild(header);
          node.appendChild(content);
        }
      } else {
        const fieldWrapper = document.createElement("div");
        fieldWrapper.classList.add("field-wrapper");
        const label = document.createElement("label");
        label.textContent = key;
        label.title = "Field name";
        let input;

        if (typeof value === "string" && value.match(/\.(jpg|jpeg|png|webp|svg)$/i)) {
          input = document.createElement("input");
          input.type = "text";
          input.value = value;
          input.title = "Click image to select from media library";

          const imgPreview = document.createElement("img");
          imgPreview.src = value;
          imgPreview.classList.add("image-preview");
          imgPreview.style.cursor = "pointer";

          imgPreview.addEventListener("click", () => {
            switchTab("media");
            const mediaList = document.getElementById("media-list");
            const handler = e => {
              if (e.target.tagName === "IMG") {
                input.value = e.target.src;
                imgPreview.src = e.target.src;
                updateRawJSON();
                mediaList.removeEventListener("click", handler);
                switchTab(activeTab);
              }
            };
            mediaList.addEventListener("click", handler);
          });

          input.addEventListener("input", () => {
            setDataAtPath(parentPath, input.value);
            imgPreview.src = input.value;
            updateRawJSON();
          });

          fieldWrapper.appendChild(imgPreview);
        } else {
          input = document.createElement("input");
          input.type = "text";
          input.value = value;
          input.title = "Click to edit value";
          input.addEventListener("input", () => {
            setDataAtPath(parentPath, input.value);
            updateRawJSON();
          });
        }

        fieldWrapper.appendChild(label);
        fieldWrapper.appendChild(input);
        node.appendChild(fieldWrapper);
      }

      return node;
    }

    container.appendChild(buildNode(data, "root", path));

    const pre = document.createElement("pre");
    pre.classList.add("json-raw");
    pre.textContent = JSON.stringify(data, null, 2);
    container.appendChild(pre);

    const toggleBtn = document.createElement("button");
    toggleBtn.textContent = "Toggle Raw / Form";
    toggleBtn.classList.add("toggle-json");
    toggleBtn.addEventListener("click", () => {
      pre.style.display = pre.style.display === "none" ? "block" : "none";
    });
    container.appendChild(toggleBtn);
  }

  document.querySelectorAll(".editor-container").forEach(container => {
    const pre = container.querySelector(".json-raw");
    const data = JSON.parse(pre.textContent);
    createEditor(container, data);
  });

  // -----------------------
  // Save All
  // -----------------------
  saveAllBtn.addEventListener("click", () => {
    document.querySelectorAll(".editor-container").forEach(container => {
      const key = container.dataset.jsonKey;
      const pre = container.querySelector(".json-raw");
      let data;
      try { data = JSON.parse(pre.textContent); }
      catch(e) { showToast(`Invalid JSON in ${key}`); return; }

      fetch(`save.php?file=${key}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      })
      .then(res => res.json())
      .then(res => res.success ? showToast(`Saved ${key} ✓`) : showToast(`Error saving ${key}`))
      .catch(() => showToast(`Error saving ${key}`));
    });
  });
});
