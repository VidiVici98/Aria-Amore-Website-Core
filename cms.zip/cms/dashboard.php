<?php
require_once "config.php";
if (!is_logged_in()) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>CMS Dashboard</title>
<link rel="stylesheet" href="css/cms.css">
</head>
<body class="cms-dashboard">
<div class="cms-header">
    <h1>Aria Amore CMS</h1>
    <div class="cms-header-buttons">
        <a href="logout.php" class="logout-btn">Logout</a>
        <button id="save-all-btn">Save All</button>
    </div>
</div>

<div class="cms-tab-bar">
    <?php foreach ($JSON_FILES as $key => $file): ?>
        <button class="tab-btn" data-tab="<?= $key ?>"><?= ucfirst($key) ?></button>
    <?php endforeach; ?>
    <button class="tab-btn" data-tab="media">Media</button>
</div>

<div class="cms-main">
    <?php foreach ($JSON_FILES as $key => $file): 
        $data = load_json($key);
    ?>
    <div class="cms-tab-content" id="tab-<?= $key ?>">
        <div class="editor-container" data-json-key="<?= $key ?>">
            <!-- JSON raw view (for advanced users) -->
            <pre class="json-raw"><?= htmlspecialchars(json_encode($data, JSON_PRETTY_PRINT)) ?></pre>

            <!-- Dynamic array editor template -->
            <div class="array-container">
                <?php if (is_array($data)) foreach ($data as $i => $item): ?>
                <div class="draggable-item" draggable="true" data-index="<?= $i ?>">
                    <span class="drag-handle" title="Drag to reorder">≡</span>
                    <div class="field-input-container">
                        <?php foreach ($item as $field => $value): ?>
                        <div class="field-wrapper">
                            <label title="<?= htmlspecialchars($field) ?>"><?= ucfirst($field) ?></label>
                            <input type="text" value="<?= htmlspecialchars(is_array($value) ? json_encode($value) : $value) ?>" data-field="<?= $field ?>">
                        </div>
                        <?php endforeach; ?>
                        <div class="field-actions">
                            <button class="edit-item" title="Edit">✎</button>
                            <button class="delete-item" title="Delete">🗑</button>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <button class="add-array-item">Add Item</button>
        </div>
    </div>
    <?php endforeach; ?>

    <div class="cms-tab-content" id="tab-media">
        <input type="file" id="media-upload">
        <div id="media-list"></div>
    </div>
</div>

<div id="toast" class="toast"></div>

<script src="js/dragdrop.js"></script>
<script src="js/media.js"></script>
<script src="js/cms.js"></script>
</body>
</html>
